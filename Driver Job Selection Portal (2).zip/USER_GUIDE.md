# Align Logic - Driver Job Selection System User Guide

## Introduction

The Job Selection System (JSS) is designed to streamline the process of job selection for UPS drivers based on seniority. This guide explains how to use both the driver and administrator interfaces of the application.

## Data Persistence

The application uses secure browser storage for session data. This means:

- All site data is stored on secure servers
- Your preferences and selections are saved automatically
- Data persists between sessions and devices
- Your data is protected and isolated from other users

## Accessing the Application

1. Navigate to https://align-logic.com in your browser
2. Login with your credentials to access your personalized dashboard

## Driver Interface

### Logging In

1. Enter your 7-digit Employee ID on the main page
   - For testing purposes, any 7-digit ID starting with 1 (e.g., 1234567) will work
2. If it's your first time, you'll be prompted to set up a password and security questions

### Navigation

The driver interface has three main tabs:
1. **Overview**: Shows job selection deadlines and your current status
2. **Weekly Jobs**: Displays available jobs and allows job selection
3. **How It Works**: Explains the job selection process

### Selecting Jobs

1. Go to the **Weekly Jobs** tab
2. Review the available jobs list
3. Drag jobs from the available jobs list to the preference list
4. Arrange them in order of preference (your first choice should be at the top)
5. Click **Submit Preferences** before the cutoff time
6. Your job assignment will be shown after the cutoff time passes

## Administrator Interface

### Logging In

1. Click the "Admin Portal" link at the bottom of the homepage
2. Enter the admin credentials:
   - Username: `admin`
   - Password: `ups123`

### Admin Dashboard

The dashboard provides comprehensive management capabilities:

#### Jobs Management
- View and edit job definitions
- Add new jobs with start times and qualifications
- Delete unnecessary jobs

#### Drivers Management
- Add new drivers with Employee IDs and seniority numbers
- Specify airport certification status and VC status
- Mark drivers as eligible or ineligible

#### Job Assignments
- View real-time job selection status
- See which drivers have submitted preferences
- View and edit final assignments
- Manually override automatic assignments if needed

#### System Settings
- Set the cutoff time for job selections
- Toggle automatic assignments
- Enable/disable seniority-based assignments
- Schedule automatic cutoff
- Toggle portal availability

### Data Import/Export

The admin interface allows you to:
1. Export driver data to CSV
2. Export job data to CSV
3. Export final assignments for reporting
4. Import data from CSV files

## Backup Recommendations

Although data is automatically saved on our secure servers, administrators should:

1. Regularly export data using the admin interface
2. Store exported CSV files in a secure location
3. Consider implementing a regular backup schedule

## Troubleshooting

### Access Issues
- If you have trouble logging in, try clearing browser cookies
- Contact your site administrator if you need password assistance
- Use any modern browser for the best experience

### Display Issues
- If the interface doesn't look right, try a different browser
- Chrome, Firefox, and Edge are recommended
- Ensure your browser is updated to the latest version

### Performance
- The application is optimized for modern browsers
- Close unnecessary tabs and applications for better performance
- For large data sets, give the application a moment to process

## Important Notes

1. The cutoff time enforces when drivers can no longer submit or change preferences
2. Airport certified drivers are automatically considered for airport jobs
3. VC (Vacation Coverage) drivers may be auto-assigned if needed
4. Data is stored only on the local computer where it was entered

## Need Help?

For additional assistance or to report issues, refer to the troubleshooting guide or contact your system administrator.