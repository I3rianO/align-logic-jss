# 🚨 VERCEL DEPLOYMENT MIGRATION - CRITICAL STEPS

## Your Current Problem
- **Vercel is serving OLD version** from GitHub/Supabase integration
- **This new JSS system** with backend/multi-tenant security is NOT deployed
- **www.align-logic.com** is pointing to outdated code

## ⚡ IMMEDIATE ACTION REQUIRED

### STEP 1: DISCONNECT OLD VERCEL DEPLOYMENT (5 minutes)

1. **Go to Vercel Dashboard**: https://vercel.com/dashboard
2. **Find your JSS project** (likely named "job-selection-system" or similar)
3. **Click on the project** → Go to Settings
4. **Git Integration** → Click "Disconnect Git Repository"
5. **Domains** → Remove www.align-logic.com from old project
6. **Delete the old project** (optional but recommended)

### STEP 2: DEPLOY NEW VERSION TO VERCEL (10 minutes)

**Option A: Upload dist/ folder directly to Vercel**
1. Download the `dist/` folder from this current build
2. Go to Vercel → "Add New Project"
3. Choose "Upload" (not Git)
4. Upload the `dist/` folder
5. Set domain to www.align-logic.com

**Option B: Create new GitHub repo (if you prefer Git workflow)**
1. Create new GitHub repository: "jss-production"
2. Upload ALL files from this current project
3. Connect Vercel to new repo
4. Set domain to www.align-logic.com

### STEP 3: CONFIGURE ENVIRONMENT (2 minutes)

In Vercel project settings:
- **Domain**: www.align-logic.com
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

### STEP 4: DNS CONFIGURATION (Squarespace)

1. **Go to Squarespace Domain Settings**
2. **DNS Records** → Add/Edit:
   - **Type**: CNAME
   - **Host**: www
   - **Value**: cname.vercel-dns.com
3. **Wait 5-15 minutes** for DNS propagation

### STEP 5: VERIFY DEPLOYMENT (5 minutes)

1. Visit www.align-logic.com
2. Should see the NEW JSS system (not old version)
3. Test admin login functionality
4. Run migration in browser console: `JSS_SETUP.runFullMigration()`

## 🔥 FASTEST PATH (RECOMMENDED)

**Skip GitHub entirely - Direct Vercel upload:**
1. Disconnect old Vercel project
2. Upload `dist/` folder to new Vercel project
3. Set www.align-logic.com domain
4. Go live in 15 minutes

## ❌ WHAT TO AVOID

- **Don't** try to fix the old GitHub/Supabase integration
- **Don't** keep the old Vercel project running
- **Don't** use the old codebase anymore

## ✅ RESULT

- www.align-logic.com serves NEW JSS system
- Multi-tenant security active
- Backend database operational
- Ready for UPS JACFL production use

**The old GitHub/Supabase version is obsolete. This new system replaces everything.**