# Align Logic - Web Deployment Guide

This document outlines the production deployment process for the Align Logic Driver Job Selection System to Vercel and connecting it to the align-logic.com domain.

## Requirements

- Node.js 16+ (for build process only)
- Static web hosting service (any provider that supports SPA hosting)
- HTTPS recommended for production deployments

## Build Process

1. Install dependencies:
   ```
   npm install
   ```

2. Build the application:
   ```
   npm run build
   ```

3. The built application will be in the `dist/` directory

## Production Deployment to Vercel

### Step 1: Prepare Vercel Account

1. Create a Vercel account at https://vercel.com/signup
2. Set up a new project from your Git repository or upload the source code directly

### Step 2: Configure Project Settings

When setting up the project in Vercel, use these settings:

- Framework Preset: Vite
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: `npm install`

The included `vercel.json` file will handle routing configuration automatically.

### Option 2: Server Deployment

If deploying to a traditional web server:

1. Copy the contents of the `dist/` directory to your web server's root or subdirectory
2. Configure your server to handle client-side routing:

For Apache (.htaccess):
```
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

For Nginx:
```
location / {
  try_files $uri $uri/ /index.html;
}
```

## Post-Deployment Verification

After deployment, verify:

1. The application loads correctly at the deployed URL
2. Driver login works properly
3. Admin Portal access works for both regular admins and Master Admin
4. UPS > JACFL site is accessible in the Admin Portal
5. Master Admin Panel is accessible using the special password

## Domain Configuration (align-logic.com)

### Squarespace DNS Configuration

After deploying to Vercel, you'll need to configure your Squarespace domain:

1. In Vercel, go to your project's "Domains" section
2. Add your domain: align-logic.com
3. Vercel will provide DNS configuration values
4. In Squarespace domain settings:
   - Add an A record pointing to Vercel's IP (typically 76.76.21.21)
   - Add CNAME records as specified by Vercel
   - Set appropriate TTL values (typically 3600 or automatic)
5. Wait for DNS propagation (may take 24-48 hours)

Vercel provides detailed instructions for connecting external domains in their dashboard.

## Security Considerations

1. Vercel automatically provides HTTPS with free SSL certificates
2. The application implements tenant isolation to keep company data separate
3. Password handling uses secure hashing for all credentials
4. Master Admin credentials should be kept confidential
5. Regular security audits are recommended

## Troubleshooting

If UPS > JACFL site is missing after deployment:

1. Clear browser cache and reload
2. Try accessing from a different browser
3. Check browser console for error messages
4. Verify localStorage is enabled and not full

## Support

For deployment assistance, contact the application developer.