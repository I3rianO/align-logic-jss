<project_instructions>
  <project_overview>
    This is a pure front-end project based on React + Vite, using TypeScript to ensure type safety. The project adopts Tailwind CSS as its styling solution, integrating the shadcn/ui component library and Lucide icon library. The project uses React Router for front-end routing management, with all routing configurations completed on the client side.
  </project_overview>

  <tech_stack>
    ## Core Tech Stack
    ```
    Front-end Framework:
    - React 18.2.0
    - Vite 6.3.1
    - TypeScript 5.7.2
    - React Router 7.5.1

    Styling Solution:
    - Tailwind CSS 3.4.1
    - shadcn/ui (based on Radix UI)
    - Lucide React 0.503.0 (Icon Library)

    Development Tools:
    - ESLint 9.22.0
    - TypeScript ESLint 8.26.1
    ```
    ⚠️ **Version Locking Warning**:
    - **Strictly prohibit modifying** the versions of the above tech stack.
    - Must follow the best practices for these technologies.
    - If the user insists on changing versions, you must first clearly inform them of potential risks (e.g., compatibility issues, build failures, etc.).
    - Only proceed with version changes if the user confirms understanding the risks and still insists.
  </tech_stack>

  <configuration>
    - shadcn/ui and Tailwind CSS are pre-configured. **DO NOT** make destructive changes to related files.
    - All shadcn/ui components are loaded into the `src/components/ui` folder and can be used directly. Ensure you use the correct props; if necessary, consult the component source code to understand available props and their types.
    - The basic routing structure is configured in `src/App.tsx`. Please add new routes in the correct format.
    - 404 error page is pre-configured with a catch-all route (`path="*"`) in `src/App.tsx`, displaying `NotFoundPage.tsx` for non-existent routes.
    - The `@/` path alias is configured and can be used directly.  
    - `useIsMobile` hook is pre-configured for mobile detection. Usage:
      ```tsx
      import { useIsMobile } from "@/hooks/use-mobile"

      // Usage within a component
      const isMobile = useIsMobile()
      // Returns boolean: true for mobile devices, false for desktop
      ```
    - `Toaster` and `useToast`: Used for displaying notifications. Example usage:
      ```tsx
      import { useToast } from "@/hooks/use-toast"

      // Usage within a component
      const { toast } = useToast()
      toast({ title: "Notification Title", description: "Notification description content" })
      ```
    - External packages can be used, but verify their compatibility and correct usage before implementation, and **update** `package.json` accordingly.
    - [Mandatory] Do not remove the `<script src="https://static.devv.ai/devv-app.js" type="module"></script>` reference in `index.html`, otherwise advanced features like element editing will not work correctly.
  </configuration>

  <first_message_instructions>
    ## First Interaction Guide [Important]
    If this conversation is the user's first request, and they have just expressed what they want to build:
    - Analyze the core value and target users of their product
    - [Mandatory] Propose a design style that aligns with the product (colors, typography, layout, visual elements)
    - Focus on creating a stunning `HomePage.tsx` with proper component splitting
    - [Mandatory] Update meta-information in `index.html` (title, description, icon, keywords)
    - Customize theme according to <theme_and_components> guidelines
    - Create separate component files for each functional module
    - For incomplete routes, use placeholder pages with "Coming Soon" messaging
    - Ensure the application is beautiful, responsive, and build-error-free

    <example>
    I'll create an elegant task management application with a focus on productivity and clean design. This app will help users organize their daily tasks with an intuitive and visually appealing interface.

    **Design Style:**
    - Modern minimalist design with clean lines
    - Blue-to-purple gradient color scheme for primary actions
    - Card-based layout with subtle shadows and rounded corners
    - Smooth hover animations and micro-interactions
    - Typography: Clean sans-serif with clear hierarchy

    **Implementation Plan:**
    1. **Homepage** - Main dashboard with task overview and quick actions
    2. **Task Management** - Add, edit, and organize tasks with categories
    3. **Progress Tracking** - Visual progress indicators and statistics

    **Future Features:**
    - User authentication (placeholder page)
    - Team collaboration (placeholder page)
    - Analytics dashboard (placeholder page)

    I'll start by implementing the homepage with a beautiful task dashboard, then create placeholder pages for other routes.
    </example>
  </first_message_instructions>

  <best_practices>
    ## Development Standards and Best Practices
    1. File Organization
    - All component files should use the `.tsx` extension.
    - Route page components should be placed in the `src/pages` directory.
    - State management code should be placed in the `src/store` directory.
    2. Create Small, Focused Components
    - Each new component or hook must be created in a new file, no matter how small.
    - Never add new components to existing files, even if they seem related.
    - Component code lines should be kept within 50 lines as much as possible.
    - Proactively suggest refactoring when files become too large.
    3. API Request Standards
    - Consistently use `Workspace` for network requests.
    - All requests must include:
      - Loading state handling.
      - Error handling mechanisms.
      - User-friendly UI feedback (e.g., loading animations, error messages).
    - API-related code should be centrally managed in the `src/api` directory.
    4. State Management
    - For simple component state, use React's built-in hooks.
    - For complex or shared state, use `zustand`:
      - Place related code in the `store` folder.
      - Split store files by functional module.
      - Export unified action methods.
  </best_practices>

  <theme_and_components>
    ## Theme and Component Management [Important]
    1. Theme System
    - Theme Color Mechanism:
      - The project is based on shadcn's design system, and a complete theme color scheme is defined using CSS variables in `src/index.css`.
      - You can modify color values (e.g., change brand colors), but variable names must remain unchanged to ensure components work correctly.
      - You can also add custom CSS variables to extend the theme system, but do not delete or rename existing variables to avoid breaking shadcn component styles.
      - Additionally, you can customize Tailwind behavior through `tailwind.config.js`, add new utility classes, or modify existing configurations.
    - **Theme Mode Policy**: Unless the user explicitly requests light/dark mode switching, focus on perfecting ONE theme mode (typically light mode). Do not implement theme switching functionality without user request.
    - Style Application Guide:
      - It is recommended (not mandatory) to use semantic shadcn theme class names (e.g., `bg-primary`, `text-muted-foreground`) for regular styles to maintain design consistency.
      - You can freely mix and match other utility classes provided by Tailwind CSS, including color, spacing, typography, and responsive design classes.
      - [Mandatory] Strictly prohibit the use of inline `style` attributes or any CSS-in-JS solutions to maintain code uniformity and maintainability.
    2. Component Usage Guide
    - shadcn/ui components are pre-installed in the `src/components/ui` directory.
    - Check the `src/components/ui` directory before using a component.
    - Inspect specific component files to ensure correct usage of internal properties.
    - Prioritize using shadcn/ui components to avoid reinventing the wheel.
    3. Custom Component Guide
    - Use PascalCase for component naming.
    - Strictly follow the Single Responsibility Principle.
    - Use TypeScript interfaces to define Props.
    - The `components/ui` directory is exclusively reserved for shadcn/ui components. Do not place any custom components here to keep the codebase clean and organized.
    - Custom components should be organized in appropriate folders under the `components` directory based on functional modules.
  </theme_and_components>

  <ui_ux_guidelines>
    ## UI/UX Guidelines
    1. User-Centricity and Empathy
    - Deeply understand the user journey: Before making any modifications, prioritize understanding the user's core needs, usage scenarios, and potential pain points.
    - Simplification and Intuition: Strive to simplify complex processes, create clear and intuitive interaction paths, and reduce cognitive load.
    - [Important] Accessibility: By default, consider basic web accessibility standards (e.g., WCAG AA level), ensuring content is available to a wider audience (e.g., sufficient color contrast, keyboard navigation support, clear labels).
      - State Visibility: Maintain clear visibility of text and controls in all interactive states (default, hover, focus, active, disabled, etc.).
      - **🚨 CRITICAL: shadcn Button Color Contrast Warning**: This is an extremely common LLM error that causes invisible buttons. When customizing shadcn Button components:
        - **NEVER** set text and background/border to the same color
        - **ALWAYS** verify color contrast in ALL states (default, hover, focus, disabled)
        - **Common Fatal Error Example**: 
          ```jsx
          // ❌ WRONG - White text on white background (invisible!)
          <Button variant="outline" className="border-white text-white">
            Button Text
          </Button>
          ```
        - **Correct Approach**:
          ```jsx
          // ✅ CORRECT - Proper contrast
          <Button variant="outline" className="border-white text-gray-900 hover:bg-white hover:text-gray-900">
            Button Text
          </Button>
          ```
        - **Always test**: Hover states, focus states, and disabled states for readability
        - Text on Image Backgrounds: When placing text on image backgrounds, use a semi-transparent overlay technique to improve readability; a recommended opacity range is 30%-70%.
    2. Visual Aesthetics and Brand Consistency
    - Pursue "Beauty" and "Pleasure": Aim to create visually attractive and delightful interfaces.
    - Professional Design Element Application: Carefully apply colors, typography, spacing, icons, micro-interactions, and animations to enhance the user experience without causing distraction.
    - **🚨 CRITICAL: Image Resources Policy**: 
      - **NEVER** generate, create, or write image files in code (base64, SVG data, etc.)
      - **ALWAYS** use Unsplash URLs for placeholder images: `https://images.unsplash.com/photo-[id]?w=[width]&h=[height]&fit=crop`
      - **Priority Rule**: Image visibility and loading reliability > thematic relevance
      - **Remember**: These are temporary placeholders - users will upload their own images later
      - **Quality Standard**: Use high-quality, professional photos that enhance design authenticity
    - **Favicon Policy**: For `index.html` favicon updates, use simple emoji or keep the default `/vite.svg` - avoid complex custom icons that may not load properly
    - Visual Hierarchy and Guidance: Establish a clear visual hierarchy to guide users' attention to the most important information and actions.
    - Stylistic Unity: Ensure new UI elements or modifications are consistent with the application's existing design language and brand identity.
    3. Responsive and Adaptive Design
    - Cross-Device Coverage: Always ensure the design provides a high-quality, consistent experience across various devices (desktop, tablet, mobile) and screen sizes.
    - Graceful Degradation and Progressive Enhancement: Ensure core functionality is available in all environments, providing an enhanced experience for modern browsers that support advanced features.
    - Layout Management: Appropriately use the preset `container` class to achieve automatic centering and responsive spacing control for the main content area, ensuring optimal readability and visual balance across different screen sizes.
    4. Clear and Effective Interaction and Feedback
    - Instant Feedback Mechanism: Provide clear, immediate visual or dynamic feedback for user actions (clicks, hovers, loading, etc.).
    - Obvious States: Ensure different element states (default, hover, active, disabled, loading, error, etc.) are clearly distinguishable.
    - User-Friendly Error Handling: Provide easy-to-understand error messages and, where possible, guide users on how to resolve issues or proceed to the next step.
    5. Performance-Aware Design
    - Smooth Experience: Optimize images, animations, and interactions to avoid lag and ensure a smooth user experience.
    - Perceived Performance: Improve the user's experience during waiting periods through loading indicators, skeleton screens, and other techniques.
  </ui_ux_guidelines>

  <llm_code_hallucination_prevention>
    ## [High Priority] JSX Syntax Issues - Critical Problems Leading to Build Failures
    JSX syntax errors will cause build failures, which can be catastrophic for deployment. Always pay close attention to the following common issues:

    <lucide_icon_usage>
    [Mandatory] Lucide Icon Usage:
    1. Before using any icon, you must consult the `.devv/LUCIDE_ICON_GUIDE.md` document.
    2. Only use icons listed in this document - if a requested icon is unavailable, use an alternative icon from the document.
    3. Verify icons using exact name matches from the document.
    4. Use the correct import syntax: `import { IconName } from "lucide-react"`
    5. Component naming must exactly match the document.
    </lucide_icon_usage>

    <quote_management>
    Quote Management in Strings [Mandatory]
    LLM common error is improperly handling quotes when writing JSX.
    Incorrect Example:
    ```jsx
    const message = 'The user's profile';
    ```
    This will cause a build failure because we haven't correctly escaped the single quote. Correct way:
    ```jsx
    const message = "The user's profile";
    // or
    const message = 'The user\'s profile';
    ```
    </quote_management>

    <special_characters>
    Special Characters in JSX [Mandatory]
    Handling characters that have special meaning in JSX syntax (like `<` and `>`) can cause problems.
    Incorrect Example:
    ```jsx
    <div>If x < y then z > a</div>
    ```
    This will cause a build error, such as: `error TS1382: Unexpected token. Did you mean `{'>'}` or `&gt;`?`
    Correct way:
    ```jsx
    <div>If x {'<'} y then z {'>'} a</div>
    // or
    <div>If x &lt; y then z &gt; a</div>
    ```
    </special_characters>
  </llm_code_hallucination_prevention>
</project_instructions>