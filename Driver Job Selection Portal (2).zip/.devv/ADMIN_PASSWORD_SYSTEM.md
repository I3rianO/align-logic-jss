# Admin Password System Documentation

## Overview

This document describes the admin password system implementation, which has been updated to ensure that admin passwords are stored and managed at the facility (site) level, not the company level.

## Key Changes

1. **Facility-Level Password Management**
   - Admin passwords are now fully independent between different sites/facilities
   - Changing the password for one facility (e.g., JACFL) does not affect other facilities (e.g., DALTX)
   - Each facility maintains its own admin credentials

2. **Consistent Password Hashing**
   - Created centralized `passwordUtils.ts` for consistent hashing across the application
   - All password hashing now uses the same implementation

3. **Site-Specific Authentication**
   - Login process now validates against the specific site's credentials
   - Password changes only affect the currently logged-in site

## Implementation Details

### Password Storage

Admin credentials are stored in the structure:

```typescript
interface AdminCredentials {
  username: string;
  passwordHash: string;
  companyId: string; // Company this admin belongs to
  siteId: string;    // Site location within the company
  isSiteAdmin: boolean;
}
```

Each credential record is unique to a specific site, allowing independent password management.

### Authentication Flow

1. **Login Process**
   - When a user attempts to log in, the system finds the specific credential for the selected company and site
   - Only validates against that specific site's password hash

2. **Password Change Process**
   - The system only updates the password for the specific site the admin is logged into
   - Retrieves site context from localStorage to ensure the correct credential is updated
   - Other sites' passwords remain unchanged

### Security Features

1. **Site Isolation**
   - Each site's admin credentials are completely isolated
   - Password changes are tracked with site-specific logging

2. **Master Password**
   - The master password (PBJ0103) continues to work across all sites
   - UPS > JACFL with master password still provides special access

## Testing

To verify the independent password system:

1. Log in to JACFL admin portal and change the password
2. Log out and verify the new password works for JACFL
3. Log in to DALTX admin portal using the original password
4. Change DALTX password and verify it doesn't affect JACFL

## Technical Notes

- The password hashing function is now centralized in `src/utils/passwordUtils.ts`
- All utilities and components that handle passwords use this centralized implementation
- Password validation is context-aware, checking against the specific site's credentials
- The master password continues to function as a universal override

This implementation ensures complete independence of admin passwords between facilities while maintaining backward compatibility with existing functionality.