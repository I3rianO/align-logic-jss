# Job Selection System - Local Deployment Instructions

This document provides comprehensive instructions for deploying the Job Selection System (JSS) application locally, from initial setup to running the application. These instructions are designed for IT personnel who will handle the deployment process.

## System Requirements

### Minimum Hardware Requirements
- CPU: Dual-core processor, 2.0 GHz or higher
- RAM: 4 GB or higher
- Disk Space: At least 2 GB free space

### Software Requirements
- Node.js (version 18.x or newer)
- npm (version 9.x or newer) - included with Node.js
- A modern web browser (Chrome, Firefox, Edge, or Safari - latest versions recommended)
- Git (optional, for version control)

## Deployment Process

### Step 1: Obtain the Application Files

#### Option A: From ZIP Archive
1. Extract the provided ZIP file to a location of your choice on the server/computer
2. The extracted folder will contain all application files and dependencies

#### Option B: From Git Repository (if applicable)
1. Open a terminal or command prompt
2. Navigate to the desired installation directory
3. Run: `git clone [repository-url]` (replace with the actual repository URL)
4. Navigate into the cloned directory: `cd job-selection-system`

### Step 2: Install Dependencies

1. Open a terminal or command prompt
2. Navigate to the application directory
3. Run the following command to install all required dependencies:
   ```bash
   npm install
   ```
4. Wait for the installation process to complete. This might take several minutes depending on your internet connection speed.

### Step 3: Configure the Application (if needed)

The application uses browser local storage by default and doesn't require a database connection or special configuration. However, if you need to modify any settings:

1. Environment variables can be set in a `.env` file in the root directory
2. For custom deployment paths, you may need to adjust the `base` property in `vite.config.ts`

### Step 4: Build the Application for Production

1. In the terminal, while in the application directory, run:
   ```bash
   npm run build
   ```
2. This will create a `dist` directory with optimized production files
3. The build process typically takes 1-3 minutes to complete

### Step 5: Test the Production Build Locally

1. After building, you can preview the production build with:
   ```bash
   npm run preview
   ```
2. By default, this will serve the application at `http://localhost:4173/`
3. Verify that the application loads correctly and functions as expected

### Step 6: Deploy to a Local Server

#### Option A: Using a Simple Static File Server
For the simplest deployment on an intranet or local environment:

1. Copy the entire `dist` directory to your web server's document root
2. Configure your web server to serve these static files
3. Ensure all requests to routes are redirected to `index.html` (for client-side routing)

#### Option B: Using Node.js Based Server
If you prefer to use Node.js to serve the application:

1. Install a simple HTTP server: `npm install -g serve`
2. Navigate to the project directory
3. Run: `serve -s dist`
4. The application will be available at `http://localhost:3000` by default

#### Option C: Using Apache or Nginx
For Apache:
1. Copy the `dist` directory contents to your Apache document root
2. Create or modify `.htaccess` file with:
   ```
   RewriteEngine On
   RewriteBase /
   RewriteRule ^index\.html$ - [L]
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule . /index.html [L]
   ```

For Nginx:
1. Copy the `dist` directory contents to your Nginx document root
2. Add this configuration to your server block:
   ```
   location / {
       try_files $uri $uri/ /index.html;
   }
   ```

### Step 7: Initial System Access

1. Once deployed, navigate to the application URL in a web browser
2. Default admin credentials:
   - Username: `admin`
   - Password: `admin`
3. **Important**: Change the default admin password immediately through the System Settings page

## Troubleshooting Common Issues

### Application Shows Blank Page
- Check browser console for JavaScript errors
- Verify all files in the `dist` directory were properly copied
- Ensure the web server has proper permissions to serve the files

### 404 Errors When Refreshing Pages
- This typically indicates the server isn't properly configured for single-page applications
- Review and correct the URL rewrite rules in your web server configuration

### API Connection Issues
- The application is front-end only and uses local storage
- No API connection issues should occur unless external services are added

## Maintenance

### Updating the Application
1. Obtain the new version of the application
2. Follow the same deployment steps above
3. Replace the existing deployed files with the new build

### Backup Recommendations
- The application stores data in browser local storage by default
- For data backup, implement a regular export of data using the application's built-in export functionality
- Store exports in a secure location with appropriate backup policies

## Security Considerations

1. The application uses client-side storage (localStorage) for data
2. Secure the admin interface by changing default credentials
3. If deployed on a public-facing server, ensure HTTPS is configured
4. Regular backups of exported data are recommended

## Support Information

For technical support or questions regarding deployment, please contact:
- Support Email: [support@example.com]
- Support Hours: [8am-5pm EST, Monday-Friday]
- Documentation: Refer to the application's user guide for operational questions