# Employee ID Auto-Routing Feature

This document explains the Employee ID Auto-Routing functionality that automatically directs drivers to their assigned facility's job selection page.

## Overview

When a driver enters their unique 7-digit Employee ID in the Driver Portal, the system:
1. Identifies the driver's assigned facility (site)
2. Routes them directly to the job selection page for that specific facility
3. Shows only jobs available at their assigned facility

## Implementation Details

### 1. Driver and Site Data Structure

Each driver has:
- A unique 7-digit Employee ID (may start with 0)
- Assignment to a specific company (e.g., UPS)
- Assignment to a specific site (e.g., JACFL, DALTX)

```typescript
// Driver data structure
interface Driver {
  employeeId: string; // Unique 7-digit ID
  name: string;
  seniorityNumber: number;
  // ... other fields
  companyId: string; // e.g., 'UPS'
  siteId: string;    // e.g., 'JACFL', 'DALTX'
}
```

### 2. Auto-Routing Flow

1. **Input Employee ID** - Driver enters their 7-digit ID on the home page
2. **Lookup Site Assignment** - System identifies the driver and retrieves their assigned site
3. **Pass Site Context** - Site information is included in the navigation state
4. **Site-Specific Jobs** - Only jobs from the driver's assigned site are displayed

### 3. Key Components

#### a. Site Lookup Utility (`employeeRouting.ts`)

This utility identifies which site a driver is assigned to:

```typescript
export const findSiteByEmployeeId = (employeeId: string) => {
  const { drivers } = useDriverStore.getState();
  const driver = drivers.find(d => d.employeeId === employeeId);
  
  if (!driver) {
    return undefined;
  }
  
  const { sites } = useDriverStore.getState();
  const site = sites.find(s => s.id === driver.siteId && s.companyId === driver.companyId);
  
  return site;
}
```

#### b. Homepage Employee ID Form

The form includes logic to look up the driver's site and include that information when navigating:

```typescript
// When driver submits their Employee ID
const driver = drivers.find(d => d.employeeId === employeeId);
      
if (driver) {
  // Auto-route to the driver's assigned facility
  const site = findSiteByEmployeeId(employeeId);
  
  if (site) {
    // Navigate to driver login with site information
    navigate('/driver-login', { 
      state: { 
        employeeId,
        siteId: site.id,
        siteName: site.name,
        companyId: site.companyId
      } 
    });
  }
}
```

#### c. Driver Login Page

Displays the site information to the driver:

```tsx
{siteInfo && (
  <div className="mt-2 text-sm font-medium text-blue-600">
    You are logging into: {siteInfo.name} ({siteInfo.id})
  </div>
)}
```

#### d. Job Selection Page

Filters jobs to only show those from the driver's assigned site:

```typescript
// Filter jobs by the driver's site - only show jobs from the same site
if (siteId && companyId) {
  result = result.filter(job => job.siteId === siteId && job.companyId === companyId);
} else if (driverInfo) {
  // Fallback to use the driver's assigned site if not provided in state
  result = result.filter(job => job.siteId === driverInfo.siteId && job.companyId === driverInfo.companyId);
}
```

## Demo Data for Testing

The system is pre-loaded with demo drivers for both JACFL and DALTX sites:

### Jacksonville, FL (JACFL) Drivers:
- `1234567` - John Smith
- `2345678` - Jane Doe
- `3456789` - Mike Johnson
- `4567890` - Sara Williams
- `0123456` - David Miller
- `0567890` - Emma Parker
- `9012345` - James Wilson
- `8765432` - Olivia Martinez

### Dallas, TX (DALTX) Drivers:
- `5678901` - Robert Chen
- `6789012` - Maria Garcia
- `7890123` - Alex Turner
- `2468101` - Thomas Wright
- `1357924` - Sarah Johnson
- `0987654` - Kevin Lee
- `0246813` - Lisa Rodriguez

## Testing the Feature

1. Open the Driver Portal
2. Enter any of the Employee IDs from the JACFL or DALTX lists
3. Observe that the system correctly identifies the facility
4. After logging in, verify that only jobs from that facility are shown
5. Test IDs that start with 0 to ensure they work correctly

## Error Handling

- If an Employee ID is not recognized, a friendly message is displayed: "Your Employee ID was not recognized or is not yet active for scheduling."
- If a driver exists but their site information is missing, a fallback approach still allows them to log in

## Security Considerations

- Site information is maintained throughout the user session
- The job filtering ensures drivers can only see and select jobs at their assigned facility
- No cross-site job selection is possible

---

This auto-routing feature ensures that drivers are seamlessly directed to their proper facility's job selection interface without requiring them to manually select their site.