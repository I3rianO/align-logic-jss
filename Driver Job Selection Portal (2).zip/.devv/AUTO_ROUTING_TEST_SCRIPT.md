# Employee ID Auto-Routing Test Script

Use this script to verify that the auto-routing feature is working correctly.

## Setup

1. Ensure the application is running
2. Open the Driver Portal homepage

## Test Case 1: Jacksonville Driver (JACFL)

**Input:** Employee ID `1234567` (John Smith)

**Expected Results:**
1. System accepts the ID and finds the driver
2. Login page shows "You are logging into: Jacksonville, FL (JACFL)"
3. After entering password, driver sees only JACFL jobs
4. Driver Information card shows "Facility: Jacksonville, FL (JACFL)"

## Test Case 2: Dallas Driver (DALTX)

**Input:** Employee ID `5678901` (Robert Chen)

**Expected Results:**
1. System accepts the ID and finds the driver
2. Login page shows "You are logging into: Dallas, TX (DALTX)"
3. After entering password, driver sees only DALTX jobs
4. Driver Information card shows "Facility: Dallas, TX (DALTX)"

## Test Case 3: Driver with Zero-Padded ID (JACFL)

**Input:** Employee ID `0123456` (David Miller)

**Expected Results:**
1. System accepts the ID despite leading zero
2. Login page shows "You are logging into: Jacksonville, FL (JACFL)"
3. After entering password, driver sees only JACFL jobs
4. Driver Information card shows "Facility: Jacksonville, FL (JACFL)"

## Test Case 4: Driver with Zero-Padded ID (DALTX)

**Input:** Employee ID `0987654` (Kevin Lee)

**Expected Results:**
1. System accepts the ID despite leading zero
2. Login page shows "You are logging into: Dallas, TX (DALTX)"
3. After entering password, driver sees only DALTX jobs
4. Driver Information card shows "Facility: Dallas, TX (DALTX)"

## Test Case 5: Invalid Employee ID

**Input:** Employee ID `9999999` (Not a valid driver)

**Expected Results:**
1. System shows error message: "Your Employee ID was not recognized or is not yet active for scheduling."
2. User remains on homepage with ID form visible

## Notes for Testers

- Password for all demo drivers: `ups123` (if prompted)
- If no password is set, you'll be prompted to create one
- Verify that available jobs shown match only the driver's assigned facility
- Verify that job preferences can be successfully saved

## Test Results

| Test Case | Pass/Fail | Notes |
|-----------|-----------|-------|
| Test Case 1 | | |
| Test Case 2 | | |
| Test Case 3 | | |
| Test Case 4 | | |
| Test Case 5 | | |