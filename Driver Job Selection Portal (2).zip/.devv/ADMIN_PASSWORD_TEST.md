# Admin Password System Test Script

This script provides step-by-step instructions to verify that admin passwords are now managed at the facility level, ensuring that changing the password for one facility doesn't affect others.

## Test Scenario: Verify Facility-Level Password Independence

### Initial Setup

**Default Admin Credentials:**
- Username: `admin`
- Password: `ups123` (for all UPS facilities)

### Test Case 1: Change JACFL Password and Verify DALTX Independence

1. **Log in to UPS > JACFL Admin Portal**
   - Open Admin Portal page
   - Select Company: UPS
   - Select Site: Jacksonville, FL (JACFL)
   - Username: admin
   - Password: ups123
   - Click "Access Admin Dashboard"
   
2. **Change JACFL Admin Password**
   - Navigate to System Settings
   - Select the "Admin Password" tab
   - Enter Current Password: ups123
   - Enter New Password: jacfl2025
   - Confirm New Password: jacfl2025
   - Click "Change Password"
   - Verify success message appears
   
3. **Log out of JACFL Admin Portal**
   - Click "Logout" or navigate back to the login screen

4. **Verify New JACFL Password Works**
   - Select Company: UPS
   - Select Site: Jacksonville, FL (JACFL)
   - Username: admin
   - Password: jacfl2025
   - Click "Access Admin Dashboard"
   - Verify you can access the dashboard

5. **Log out of JACFL Admin Portal**

6. **Log in to UPS > DALTX Admin Portal**
   - Select Company: UPS
   - Select Site: Dallas, TX (DALTX)
   - Username: admin
   - Password: ups123 (original password)
   - Click "Access Admin Dashboard"
   - Verify you can access the dashboard with the original password
   
7. **Change DALTX Admin Password**
   - Navigate to System Settings
   - Select the "Admin Password" tab
   - Enter Current Password: ups123
   - Enter New Password: daltx2025
   - Confirm New Password: daltx2025
   - Click "Change Password"
   - Verify success message appears

8. **Log out of DALTX Admin Portal**

9. **Verify Both Passwords Work Independently**
   - Log in to JACFL with password: jacfl2025 (should succeed)
   - Log out
   - Log in to DALTX with password: daltx2025 (should succeed)
   - Log out
   - Attempt to log in to JACFL with password: daltx2025 (should fail)
   - Attempt to log in to DALTX with password: jacfl2025 (should fail)

### Test Case 2: Verify Master Password Continues Working

1. **Verify Master Password for JACFL**
   - Select Company: UPS
   - Select Site: Jacksonville, FL (JACFL)
   - Username: admin
   - Password: PBJ0103 (master password)
   - Verify you can access the master admin dashboard

2. **Verify Master Password for DALTX**
   - Select Company: UPS
   - Select Site: Dallas, TX (DALTX)
   - Username: admin
   - Password: PBJ0103 (master password)
   - Verify you can access the admin dashboard

### Test Case 3: Password Reset Verification

1. **Reset JACFL Password**
   - Log in to the Master Admin Portal (UPS > JACFL with PBJ0103)
   - Navigate to User Management
   - Find JACFL site admins
   - Reset password for JACFL admin
   - Verify the reset password is set to default (ups123)

2. **Reset DALTX Password**
   - From the same Master Admin session
   - Find DALTX site admins
   - Reset password for DALTX admin
   - Verify the reset password is set to default (ups123)

3. **Verify Reset Passwords**
   - Log in to JACFL with password: ups123 (should succeed)
   - Log in to DALTX with password: ups123 (should succeed)

## Expected Results

- Each facility's admin password can be changed independently
- Changing one facility's password does not affect other facilities
- The master password (PBJ0103) continues to work for all facilities
- Password resets affect only the targeted facility

## Notes

- If any test fails, document the specific failure and how it differs from the expected behavior
- Some older browser sessions may need a full refresh or cache clearing if credentials were previously stored