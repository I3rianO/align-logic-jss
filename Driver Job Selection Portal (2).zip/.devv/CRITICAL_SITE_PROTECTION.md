# Critical Site Protection: UPS > JACFL

## Overview

This document explains the protection mechanisms implemented to ensure the UPS > JACFL site is always preserved in the system, regardless of application updates, deployment methods, or data resets.

## Importance

The UPS > JACFL site is **critical** to the system for the following reasons:

1. **Master Admin Access**: The Master Admin Panel is only accessible through UPS > JACFL with password PBJ0103
2. **Jacksonville Driver Portal**: Driver access to the Jacksonville location requires this site
3. **System Management**: Core administrative functions depend on this site's existence

## Protection Mechanisms

Multiple layers of protection have been implemented to ensure UPS > JACFL always exists:

### 1. Definitive Implementation (`criticalSiteRestore.ts`)

- Authoritative implementation with hardcoded UPS and JACFL data
- Runs at application startup, component initialization, and login attempts
- Performs dual verification and restoration in both Zustand state and localStorage
- Contains emergency recovery procedures as last resort

### 2. Direct Storage Manipulation (`directStorageRestore.ts`)

- Bypasses normal state management to directly modify localStorage
- Creates basic storage structure with UPS and JACFL if none exists
- Enforces consistent password hashing across all mechanisms

### 3. Force Initialization (`forceInitJACFL.ts`)

- Legacy implementation maintained for compatibility
- Creates UPS company and JACFL site if missing
- Verifies admin credentials for UPS JACFL access

### 4. Runtime Verification

- Periodic checks (every 5 seconds) during application runtime
- Verifies UPS JACFL exists and restores it if missing
- Monitors both Zustand state and localStorage for consistency

### 5. Component-Level Protection

- Admin Portal component verifies UPS JACFL exists on mount
- Login handler ensures UPS JACFL exists before processing login attempts
- All site operations check for UPS JACFL before executing

## Hardcoded Values (Never Change)

These values are hardcoded throughout the system and must never be changed:

- **Company ID**: `UPS`
- **Site ID**: `JACFL`
- **Site Name**: `Jacksonville, FL`
- **Admin Username**: `admin`
- **Admin Password**: `ups123` (for UPS sites)
- **Master Password**: `PBJ0103` (only works with UPS > JACFL)

## Testing Verification

After each deployment, verify:

1. UPS appears exactly once in the company dropdown
2. Jacksonville, FL appears as a site option under UPS
3. Login with admin/ups123 works for UPS > JACFL
4. Master Admin access works with password PBJ0103
5. Jacksonville driver portal is accessible

## Technical Implementation

The primary protection logic is in these files:

- `/src/utils/criticalSiteRestore.ts` - Definitive implementation
- `/src/utils/directStorageRestore.ts` - Direct localStorage manipulation
- `/src/utils/forceInitJACFL.ts` - Legacy force restoration
- `/src/main.tsx` - Application initialization
- `/src/store/persistenceInit.ts` - Store initialization
- `/src/pages/AdminPortalPage.tsx` - Login component protection

## Debugging

If issues occur, check browser console for these indicators:

- `🛡️ CRITICAL: Executing definitive UPS JACFL site integrity check`
- `🚨 CRITICAL RESTORATION: [component] missing from state`
- `🔐 Updating Zustand store with critical UPS JACFL data`
- `✅ UPS JACFL verification passed`
- `💥 EMERGENCY: Executing last resort recovery for UPS JACFL`

## Deployment Notes

- Any deployment should maintain these protection mechanisms
- Do not remove any of the site protection code
- If adding new functionality, ensure it respects these protection mechanisms
- Test UPS JACFL access after any code changes