# Lucide Icon Guide

This document lists all the available Lucide icons used in the Job Selection System (JSS) project. When using icons, make sure to:

1. Only use icons from this list
2. Use the exact name as shown here
3. Import using: `import { IconName } from "lucide-react"`

## Currently Used Icons

- `ChevronLeft` - Used for back navigation
- `ChevronRight` - Used for forward navigation or continuing
- `ChevronDown` - Used for dropdown indicators and moving items down
- `ChevronUp` - Used for collapsible sections and moving items up
- `ClipboardList` - Used for job lists
- `Download` - Used for downloading/exporting files
- `ExternalLink` - Used for external links
- `FileSpreadsheet` - Used for Excel operations
- `FileText` - Used for PDF documents 
- `HelpCircle` - Used for help sections
- `Info` - Used for information alerts
- `Key` - Used for password/security indicators
- `Loader2` - Used for loading animations
- `LockKeyhole` - Used for authentication/security
- `Plus` - Used for adding items
- `PlusCircle` - Used for adding new items
- `RefreshCcw` - Used for refreshing/reloading data
- `Save` - Used for saving changes
- `Settings` - Used for settings/configuration
- `ShieldCheck` - Used for admin access
- `Sparkles` - Used for decorative elements
- `Trash2` - Used for deletion actions
- `UploadCloud` - Used for uploading files
- `User` - Used for user/employee identification
- `UserCheck` - Used for driver verification/approval
- `Users` - Used for groups of users/drivers
- `X` - Used for closing or cancelling
- `CheckCircle` - Used for success indications

## Additional Available Icons

- `AlertCircle` - Use for important alerts
- `AlertTriangle` - Use for warnings
- `ArrowDown` - Use for downward direction
- `ArrowLeft` - Use for leftward direction
- `ArrowRight` - Use for rightward direction
- `ArrowUp` - Use for upward direction
- `Calendar` - Use for date-related functions
- `Check` - Use for success/completion indicators
- `Clock` - Use for time-related functions
- `Edit` - Use for editing functions
- `Eye` - Use for visibility toggles
- `EyeOff` - Use for hiding content
- `Filter` - Use for filtering functions
- `Home` - Use for home navigation
- `LogOut` - Use for logout functions
- `Mail` - Use for email functions
- `Menu` - Use for menu toggles
- `MoreHorizontal` - Use for overflow menus
- `Search` - Use for search functions
- `SlidersHorizontal` - Use for adjustable settings
- `Smartphone` - Use for mobile views
- `Star` - Use for favorites or ratings