# Configure Squarespace Domain for New Deployment

## 🔧 Squarespace Domain Configuration

Since you purchased www.align-logic.com through Squarespace, you'll need to update the DNS settings to point to your new deployment.

### Step 1: Access Squarespace Domain Settings
1. Go to https://account.squarespace.com
2. Log in to your account
3. Click **Domains** in the main menu
4. Find `align-logic.com` and click **Manage**

### Step 2: Update DNS Settings

#### Option A: Point to Netlify (Recommended)
If deploying to Netlify:
1. In Squarespace DNS settings
2. Delete any existing A records or CNAME for www
3. Add new CNAME record:
   - **Name**: `www`
   - **Value**: `your-app-name.netlify.app` (you'll get this after Netlify deployment)

#### Option B: Point to New Vercel Project
If creating a new Vercel project:
1. In Squarespace DNS settings
2. Delete any existing A records or CNAME for www
3. Add new CNAME record:
   - **Name**: `www`
   - **Value**: `your-new-project.vercel.app`

### Step 3: Root Domain Redirect (Optional)
To redirect `align-logic.com` to `www.align-logic.com`:
1. Add A record for root domain:
   - **Name**: `@` (or leave blank)
   - **Value**: IP address from your hosting provider
2. Or add CNAME:
   - **Name**: `@`
   - **Value**: `www.align-logic.com`

### Step 4: Verify DNS Propagation
1. Use https://dnschecker.org
2. Enter `www.align-logic.com`
3. Check that it resolves to your new hosting provider
4. DNS changes can take 24-48 hours to fully propagate

## 🚀 Deployment Timeline

1. **Disconnect Vercel** (10 min) - Domain becomes available
2. **Deploy new JSS** (15 min) - Upload to Netlify/new Vercel
3. **Update Squarespace DNS** (5 min) - Point to new deployment
4. **Wait for propagation** (1-48 hours) - DNS changes take effect
5. **Run migration** (2 min) - Activate backend in browser console

## ✅ Success Indicators

- www.align-logic.com loads your new JSS system
- No more GitHub/Supabase errors
- Multi-tenant login works properly
- Admin dashboard shows proper data isolation

---

**Your domain will be ready for the new production JSS deployment once these DNS changes propagate.**